using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using Handcraft_Route.infrastructure.Repositories;
using Handcraft_Route.domain.Entities;
using Handcraft_Route.domain.dtos;
using System.Security.AccessControl;
using System.Runtime.InteropServices;

namespace Handcraft_Route.api.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class ArteController : ControllerBase
    {
        [HttpGet]
        [Route("Todos")]
        public IActionResult All()
        {
            var repository = new ArtesanosSQLrepositorys();
            var Hand = repository.HRCDatosArt();
            var Respuesta = Hand.Select(g => CreateDtoFromObject(g));
            return Ok(Respuesta);
        } 

        private ArtesanoRespond CreateDtoFromObject(Artesano Art)
        {
            var query = new ArtesanoRespond(

                NombreArtesano : Art.NombreArtesano,
                MunicipioLocalidad : Art.MunicipioLocalidad,
                TallerNegocio : Art.TallerNegocio,
                Correo : Art.Correo,
                RedesSociales : Art.RedesSociales
            );
            return query;
        }


        #region"Request"
        private Artesano CreateObjectFromDto(ArtesanoRequest dto)
        {
            var query = new Artesano {
                IdArtesanos = 0,
                NombreArtesano = string.Empty,
                MunicipioLocalidad = string.Empty,
                TallerNegocio = string.Empty,
                LogotipoNegocio = string.Empty,
                Correo = string.Empty,
                RedesSociales = string.Empty,
                Ubicacion = string.Empty,
                GeoUbicacion = string.Empty
            };
            return query;
        }
        #endregion
    }
}