using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using Handcraft_Route.infrastructure.Repositories;
using Handcraft_Route.domain.Entities;
using Handcraft_Route.domain.dtos;
using System.Security.AccessControl;
using System.Runtime.InteropServices;

namespace Handcraft_Route.api.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class ArtesanoProductController : ControllerBase
    {
        [HttpGet]
        [Route("Todos")]
        public IActionResult All()
        {
            var repository = new ProductosArtSQLrepositorys();
            var Hand = repository.HRCArt();
            var Respuesta = Hand.Select(g => CreateDtoFromObject(g));
            return Ok(Respuesta);
        } 

        private ArtesanoProdcutosRespond CreateDtoFromObject(ProductosArtesano Pro)
        {
            var query = new ArtesanoProdcutosRespond(

                NombreProducto : Pro.NombreProducto,
                Descripcion : Pro.Descripcion,
                MaterialElaborado : Pro.MaterialElaborado
            );
            return query;
        }


        #region"Request"
        private ProductosArtesano CreateObjectFromDto(ArtesanoProductosRequest dto)
        {
            var query = new ProductosArtesano {
                IdProductos = 0,
                NombreProducto = string.Empty,
                Descripcion = string.Empty,
                MaterialElaborado = string.Empty,
                Fotografia = string.Empty
            };
            return query;
        }
        #endregion
    }
}