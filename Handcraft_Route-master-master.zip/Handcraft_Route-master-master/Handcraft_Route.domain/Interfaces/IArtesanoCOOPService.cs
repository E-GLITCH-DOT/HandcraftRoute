using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Handcraft_Route.domain.Entities;

namespace Handcraft_Route.domain.Interfaces
{
    public interface IArtesanoCOOPService
    {
        bool ValidateArtesanoCoop (ArtesanosCooperativa artesanosCooperativa);
        bool ValidateUpdateArtesanosCoop (ArtesanosCooperativa artesanosCooperativa);
    }
}