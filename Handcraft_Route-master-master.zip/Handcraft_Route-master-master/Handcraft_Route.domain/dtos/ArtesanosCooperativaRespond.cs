using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Handcraft_Route.domain.dtos
{
    public record ArtesanosCooperativaRespond (string NombreComercio, string Telefono, string Descripcion );
}