using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Handcraft_Route.infrastructure.Data;
using Handcraft_Route.domain.Entities;
using Handcraft_Route.domain.Interfaces;
using Microsoft.EntityFrameworkCore;


namespace Handcraft_Route.infrastructure.Repositories
{
    public class ArtesanosCoopSQLrepositorys :IArtesanosCOOPRespository
    {
        private readonly CFPHandcraftRouteContext _context;

        public ArtesanosCoopSQLrepositorys(CFPHandcraftRouteContext context)
        {
            _context = context;
        }

        public async Task<IEnumerable<ArtesanosCooperativa>> HCRdatos() //todos los datos
        {
            var artesanosCooperativas = _context.ArtesanosCooperativas.Select(All => All);
            return await artesanosCooperativas.ToListAsync();
        }

        public async Task<ArtesanosCooperativa> BuscarID(int id)
        {
            var query = await _context.ArtesanosCooperativas.FirstOrDefaultAsync(co => co.IdCooperativa == id);
            return query;
        }


        public async Task<int> create(ArtesanosCooperativa artesanosCooperativa)
        {
            var entity = artesanosCooperativa;
            await _context.ArtesanosCooperativas.AddAsync(entity);
            var rows = await _context.SaveChangesAsync();

            if(rows <= 0)
                throw new Exception("El registro no pudo ser completado");
            
            return entity.IdCooperativa;
        }

        public async Task<bool> Update(int id, ArtesanosCooperativa artesanosCooperativa)
        {
            if(id <= 0 || artesanosCooperativa == null)
                throw new ArgumentException("Falta informacion para poder realizar la modificacion");

            var entity = await BuscarID(id);

            entity.NombreComercio = artesanosCooperativa.NombreComercio;
            entity.Telefono = artesanosCooperativa.Telefono;
            entity.Descripcion = artesanosCooperativa.Descripcion;
            entity.Platillo1 = artesanosCooperativa.Platillo1;
            entity.Platillo2 = artesanosCooperativa.Platillo2;
            entity.Platillo3 = artesanosCooperativa.Platillo3;
            entity.Ubicacion = artesanosCooperativa.Ubicacion;
            entity.GeoUbicacion = artesanosCooperativa.GeoUbicacion;

            _context.Update(entity);

            var rows = await _context.SaveChangesAsync();
            return rows > 0;
        }

    }
}