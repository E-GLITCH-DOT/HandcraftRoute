using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Handcraft_Route.infrastructure.Data;
using Handcraft_Route.domain.Entities;

namespace Handcraft_Route.infrastructure.Repositories
{
    public class ArtesanosSQLrepositorys
    {
        private readonly CFPHandcraftRouteContext _HRC;

        public ArtesanosSQLrepositorys()
        {
            _HRC = new CFPHandcraftRouteContext();
        }
        public IEnumerable<Artesano> HRCDatosArt()
        {
            var Artesanos = _HRC.Artesanos.Select(dn => dn);
            return Artesanos;
        }
    }
}