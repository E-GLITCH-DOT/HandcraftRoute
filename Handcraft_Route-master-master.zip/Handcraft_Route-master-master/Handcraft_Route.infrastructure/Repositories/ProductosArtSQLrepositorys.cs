using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Handcraft_Route.infrastructure.Data;
using Handcraft_Route.domain.Entities;

namespace Handcraft_Route.infrastructure.Repositories
{
    public class ProductosArtSQLrepositorys
    {
        private readonly CFPHandcraftRouteContext _HRCArt;

        public ProductosArtSQLrepositorys()
        {
            _HRCArt = new CFPHandcraftRouteContext();
        }
        public IEnumerable<ProductosArtesano> HRCArt()
        {
            var Productos = _HRCArt.ProductosArtesanos.Select(Pa => Pa);
            return Productos;
        }
    }
}